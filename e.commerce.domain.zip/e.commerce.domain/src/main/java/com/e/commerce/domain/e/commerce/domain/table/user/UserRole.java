//package com.e.commerce.domain.e.commerce.domain.table.user;
//
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "User_role")
//public class UserRole {
//    @Id
//   private long user_id;
//     private long role_id;
//}
